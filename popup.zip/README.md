[![GitHub stars](https://img.shields.io/github/stars/Kealthals/SalesforceProductionWarning.svg)](https://github.com/Kealthals/SalesforceProductionWarning/stargazers)
[![GitHub issues](https://img.shields.io/github/issues/Kealthals/SalesforceProductionWarning.svg)](https://github.com/Kealthals/SalesforceProductionWarning/issues)
[![GitHub license](https://img.shields.io/github/license/Kealthals/SalesforceProductionWarning.svg)](https://github.com/Kealthals/SalesforceProductionWarning/blob/master/LICENSE)
# SalesforceProductionWarning

https://addons.mozilla.org/en-US/firefox/addon/salesforceproductionwarning/

Help Salesforce Developers and Admins to distinguish Sandbox and Production easily by add a red border on page.